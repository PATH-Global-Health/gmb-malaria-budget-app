/* Methods tab — side-panel layout with grouped navigation: overview, a section
   per intervention, the methodology sections, and the data viewer (population +
   incidence). Content lives in GMB.content.methods; data via GMB.dataViewer. */
window.GMB = window.GMB || {};
GMB.tabs = GMB.tabs || {};

(function (G) {
  var el = G.ui.el;
  var active = "overview", rootEl = null;

  function M() { return (G.content && G.content.methods) || { overview: {}, interventions: [], sections: {} }; }

  function navItems() {
    var m = M(), items = [{ type: "item", key: "overview", label: "Overview" }];
    items.push({ type: "heading", label: "By intervention" });
    m.interventions.forEach(function (iv) { items.push({ type: "item", key: "iv:" + iv.code, label: iv.name }); });
    items.push({ type: "heading", label: "Methods" });
    ["costing", "assumptions", "data", "limitations"].forEach(function (k) { if (m.sections[k]) items.push({ type: "item", key: k, label: m.sections[k].title }); });
    items.push({ type: "heading", label: "Explore the data" });
    items.push({ type: "item", key: "data:population", label: "Population" });
    items.push({ type: "item", key: "data:households", label: "Households" });
    items.push({ type: "item", key: "data:incidence", label: "Incidence" });
    return items;
  }

  function render(root) { rootEl = root; renderBody(); }

  function renderBody() {
    rootEl.innerHTML = "";
    var items = navItems();
    if (!items.some(function (i) { return i.type === "item" && i.key === active; })) active = "overview";

    var side = el("aside", { class: "methods-nav" }, [el("div", { class: "methods-nav-h", text: "Methods & data" })]);
    items.forEach(function (it) {
      if (it.type === "heading") side.appendChild(el("div", { class: "methods-nav-group", text: it.label }));
      else side.appendChild(el("button", { class: "methods-nav-item" + (it.key === active ? " on" : ""), onClick: function () { active = it.key; renderBody(); } }, [it.label]));
    });

    var main = el("div", { class: "methods-main" }, [renderSection()]);
    rootEl.appendChild(el("div", { class: "methods-layout" }, [side, main]));
  }

  function renderSection() {
    var m = M();
    if (active === "overview") return overviewView(m.overview);
    if (active.slice(0, 3) === "iv:") { var iv = m.interventions.filter(function (x) { return x.code === active.slice(3); })[0]; return iv ? ivView(iv) : el("div"); }
    if (active.slice(0, 5) === "data:") { var c = el("div", { class: "methods-data" }); if (G.dataViewer) G.dataViewer.render(c, active.slice(5)); return c; }
    return sectionView(m.sections[active]);
  }

  function overviewView(o) {
    var p = el("div", { class: "panel methods-sec" }, [el("h2", { text: "How this tool works" }), el("p", { class: "lead", text: o.lead })]);
    p.appendChild(G.ui.blocks(o.blocks));
    return p;
  }

  function ivView(iv) {
    var p = el("div", { class: "panel methods-sec" });
    p.appendChild(el("div", { class: "iv-head" }, [el("h2", { text: iv.name }), el("span", { class: "iv-target", text: "Targets: " + iv.target })]));
    p.appendChild(el("p", { class: "lead", text: iv.plain }));
    p.appendChild(el("div", { class: "method-block" }, [el("div", { class: "mb-label", text: "Quantification" }), el("div", { class: "formula big", text: iv.quant })]));
    var cols = el("div", { class: "iv-cols" });
    cols.appendChild(el("div", { class: "callout info" }, [el("div", { class: "callout-title", text: "Default assumptions" }), el("ul", {}, iv.assumptions.map(function (a) { return el("li", { text: a }); }))]));
    if (iv.notes && iv.notes.length) cols.appendChild(el("div", { class: "callout note" }, [el("div", { class: "callout-title", text: "Important notes" }), el("ul", {}, iv.notes.map(function (n) { return el("li", { text: n }); }))]));
    p.appendChild(cols);
    return p;
  }

  function sectionView(sec) {
    if (!sec) return el("div");
    var p = el("div", { class: "panel methods-sec" }, [el("h2", { text: sec.title }), el("p", { class: "lead", text: sec.lead })]);
    p.appendChild(G.ui.blocks(sec.blocks));
    return p;
  }

  G.tabs.methods = { render: render };
})(GMB);
