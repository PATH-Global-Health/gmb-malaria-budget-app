/* Builds a comprehensive, multi-sheet Excel workbook for a generated budget —
   the artefact a programme would attach to a funding application. Returns a
   `sheets` array for GMB.xlsx.download(). Used by the Generation and
   Visualisation tabs. Breakdown sheets carry a column per plan year plus an
   all-years total; the intervention sheet nests its cost-category children, and
   the district sheet adds a coloured, bold regional subtotal row. */
window.GMB = window.GMB || {};

(function (G) {
  var CLASS = { PROC: "Procurement", DIST: "Distribution", OPS: "Operational", SUPP: "Support", "M&E": "Monitoring & evaluation", COM: "Communication", ADMIN: "Administration", OTHER: "Other" };
  function ivName(c) { var x = G.catalogByCode(c); return x ? x.nice : c; }
  function className(c) { return CLASS[c] || c; }

  /* Sum cost_usd/cost_local over rows, broken out by year.
     Returns { order:[keys by total desc], m:{ key:{ u, l, yr:{year:{u,l}} } } }. */
  function byDimYear(rows, keyFn) {
    var m = {}, order = [];
    rows.forEach(function (r) {
      var k = keyFn(r); if (k == null) return;
      if (!(k in m)) { m[k] = { u: 0, l: 0, yr: {} }; order.push(k); }
      var e = m[k]; e.u += r.cost_usd || 0; e.l += r.cost_local || 0;
      var y = e.yr[r.year] || (e.yr[r.year] = { u: 0, l: 0 });
      y.u += r.cost_usd || 0; y.l += r.cost_local || 0;
    });
    order.sort(function (a, b) { return m[b].u - m[a].u; });
    return { order: order, m: m };
  }
  function rd(n) { return Math.round(n || 0); }

  /** opts: { rows, quantityRows, filters } — defaults to the budget's full data. */
  G.budgetSheets = function (b, opts) {
    opts = opts || {};
    var cur = (b.aggregates && b.aggregates.currency) || "GMD";
    var rows = opts.rows || b.costRows || [], qrows = opts.quantityRows || b.quantityRows || [];
    var years = (b.aggregates && b.aggregates.years && b.aggregates.years.slice()) || [];
    if (!years.length) { var ys = {}; rows.forEach(function (r) { ys[r.year] = 1; }); years = Object.keys(ys).map(Number).sort(function (a, c) { return a - c; }); }
    var totU = rows.reduce(function (a, r) { return a + (r.cost_usd || 0); }, 0), totL = rows.reduce(function (a, r) { return a + (r.cost_local || 0); }, 0);
    var pop = (b.aggregates && b.aggregates.national_pop_last_year) || 0;
    var cU = "Cost (USD)", cL = "Cost (" + cur + ")";
    var meta = [["Budget", b.name || ""], ["Scenario", b.scenarioName || ""], ["Cost set", b.costSetName || ""], ["Generated", (b.generatedAt || "").slice(0, 10)]];
    if (opts.filters) meta.push(["Filters applied", opts.filters]);

    // Year columns (USD) + all-years totals in both currencies.
    function yearCols() { return years.map(function (y) { return { label: String(y) + " (USD)", width: 95, fmt: "money" }; }); }
    function yearVals(e) { return years.map(function (y) { return rd((e.yr[y] || {}).u); }); }
    function yearTotalUsd(set) { return years.map(function (y) { return rd(set.reduce(function (a, e) { return a + ((e.yr[y] || {}).u || 0); }, 0)); }); }
    var tailCols = [{ label: "Total (USD)", width: 120, fmt: "money" }, { label: "Total (" + cur + ")", width: 130, fmt: "money" }];

    var sheets = [];
    sheets.push({ name: "Summary", title: "Budget summary — " + (b.name || ""), meta: meta,
      columns: [{ label: "Item", width: 240 }, { label: "Amount", width: 150, fmt: "money" }],
      rows: [["Total cost (USD)", rd(totU)], ["Total cost (" + cur + ")", rd(totL)],
        ["Cost per person (USD)", pop ? rd(totU / pop) : ""], ["Plan years", years.length ? (years[0] + "–" + years[years.length - 1]) : ""],
        ["Interventions costed", byDimYear(rows, function (r) { return r.intervention_code; }).order.length]] });

    // By intervention — parent rows with cost-category children nested beneath.
    var ivAgg = byDimYear(rows, function (r) { return r.intervention_code; });
    var ivRows = [];
    ivAgg.order.forEach(function (code) {
      var e = ivAgg.m[code];
      ivRows.push({ kind: "parent", cells: [ivName(code)].concat(yearVals(e)).concat([rd(e.u), rd(e.l)]) });
      var clsAgg = byDimYear(rows.filter(function (r) { return r.intervention_code === code; }), function (r) { return r.cost_class; });
      clsAgg.order.forEach(function (cls) {
        var ce = clsAgg.m[cls];
        ivRows.push({ kind: "child", cells: ["↳ " + className(cls)].concat(yearVals(ce)).concat([rd(ce.u), rd(ce.l)]) });
      });
    });
    sheets.push({ name: "By intervention", title: "Cost by intervention (with cost categories)",
      columns: [{ label: "Intervention / cost category", width: 240 }].concat(yearCols()).concat(tailCols),
      rows: ivRows,
      totalRow: ["TOTAL"].concat(yearTotalUsd(ivAgg.order.map(function (k) { return ivAgg.m[k]; }))).concat([rd(totU), rd(totL)]) });

    function dimSheet(name, title, label, width, keyFn, labelFn) {
      var agg = byDimYear(rows, keyFn);
      return { name: name, title: title,
        columns: [{ label: label, width: width }].concat(yearCols()).concat(tailCols),
        rows: agg.order.map(function (k) { var e = agg.m[k]; return [labelFn ? labelFn(k) : k].concat(yearVals(e)).concat([rd(e.u), rd(e.l)]); }),
        totalRow: ["TOTAL"].concat(yearTotalUsd(agg.order.map(function (k) { return agg.m[k]; }))).concat([rd(totU), rd(totL)]) };
    }
    sheets.push(dimSheet("By cost category", "Cost by category", "Cost category", 200, function (r) { return r.cost_class; }, className));

    // By year — simple per-year totals.
    var gy = byDimYear(rows, function (r) { return r.year; });
    sheets.push({ name: "By year", title: "Cost by year",
      columns: [{ label: "Year", width: 80 }, { label: cU, width: 120, fmt: "money" }, { label: cL, width: 130, fmt: "money" }],
      rows: years.map(function (y) { var e = gy.m[y] || { u: 0, l: 0 }; return [y, rd(e.u), rd(e.l)]; }), totalRow: ["TOTAL", rd(totU), rd(totL)] });

    sheets.push(dimSheet("By region", "Cost by region", "Region", 160, function (r) { return r.adm1; }));

    // By district — districts grouped under each region with a coloured regional subtotal row.
    var regAgg = byDimYear(rows, function (r) { return r.adm1; });
    var distRows = [];
    regAgg.order.slice().sort(function (a, c) { return String(a).localeCompare(String(c)); }).forEach(function (region) {
      var regionRows = rows.filter(function (r) { return r.adm1 === region; });
      var dAgg = byDimYear(regionRows, function (r) { return r.adm2; });
      dAgg.order.slice().sort(function (a, c) { return String(a).localeCompare(String(c)); }).forEach(function (d2) {
        var e = dAgg.m[d2];
        distRows.push([region, d2].concat(yearVals(e)).concat([rd(e.u), rd(e.l)]));
      });
      var re = regAgg.m[region];
      distRows.push({ kind: "sub", cells: [region + " — subtotal", ""].concat(yearVals(re)).concat([rd(re.u), rd(re.l)]) });
    });
    sheets.push({ name: "By district", title: "Cost by district (with regional subtotals)",
      columns: [{ label: "Region", width: 150 }, { label: "District", width: 150 }].concat(yearCols()).concat(tailCols),
      rows: distRows,
      totalRow: ["TOTAL", ""].concat(yearTotalUsd(regAgg.order.map(function (k) { return regAgg.m[k]; }))).concat([rd(totU), rd(totL)]) });

    // Quantities — per-year quantity columns + all-years total.
    var qm = {}, qo = [];
    qrows.forEach(function (r) {
      var k = r.intervention_code + "|" + (r.type || "") + "|" + r.commodity;
      if (!(k in qm)) { qm[k] = { iv: r.intervention_code, type: r.type || "", com: r.commodity, q: 0, tp: 0, yr: {} }; qo.push(k); }
      var e = qm[k]; e.q += r.quantity || 0; e.tp += r.target_pop || 0;
      e.yr[r.year] = (e.yr[r.year] || 0) + (r.quantity || 0);
    });
    qo.sort(function (a, c) { return qm[c].q - qm[a].q; });
    sheets.push({ name: "Quantities", title: "Commodity quantities by year",
      columns: [{ label: "Intervention", width: 200 }, { label: "Type", width: 120 }, { label: "Commodity", width: 150 }]
        .concat(years.map(function (y) { return { label: String(y) + " qty", width: 90, fmt: "int" }; }))
        .concat([{ label: "All years", width: 110, fmt: "int" }, { label: "Population targeted", width: 130, fmt: "int" }]),
      rows: qo.map(function (k) { var m = qm[k]; return [ivName(m.iv), m.type, m.com].concat(years.map(function (y) { return rd(m.yr[y]); })).concat([rd(m.q), rd(m.tp)]); }) });

    sheets.push({ name: "Cost detail", title: "Detailed cost lines",
      columns: [{ label: "Region", width: 140 }, { label: "District", width: 140 }, { label: "Year", width: 60 }, { label: "Intervention", width: 190 }, { label: "Cost category", width: 130 }, { label: cU, width: 110, fmt: "money" }, { label: cL, width: 120, fmt: "money" }],
      rows: rows.map(function (r) { return [r.adm1, r.adm2, r.year, ivName(r.intervention_code), className(r.cost_class), rd(r.cost_usd), rd(r.cost_local)]; }) });

    return sheets;
  };
})(GMB);
