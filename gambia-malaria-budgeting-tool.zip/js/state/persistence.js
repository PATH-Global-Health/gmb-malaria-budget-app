/* localStorage persistence (data volume is tiny).
   One namespaced key holds all scenarios/costSets/budgets.
   Schema is versioned for forward migration. */
window.GMB = window.GMB || {};

(function (G) {
  var KEY = "gmb_mbt_v1";
  var SCHEMA = 1;
  var saveTimer = null;

  var persistence = {
    load: function () {
      try {
        var raw = localStorage.getItem(KEY);
        if (!raw) return null;
        var obj = JSON.parse(raw);
        // (future) migrate obj.schemaVersion -> SCHEMA here
        return obj.data || null;
      } catch (e) {
        console.warn("Could not load saved data:", e);
        return null;
      }
    },

    /** Debounced save of the persistable collections. */
    save: function (state) {
      clearTimeout(saveTimer);
      saveTimer = setTimeout(function () {
        try {
          var payload = {
            schemaVersion: SCHEMA,
            savedAt: new Date().toISOString(),
            data: {
              scenarios: state.scenarios,
              costSets: state.costSets,
              budgets: state.budgets,
              removedSeeds: state.removedSeeds
            }
          };
          localStorage.setItem(KEY, JSON.stringify(payload));
        } catch (e) {
          console.error("Could not save data:", e);
        }
      }, 250);
    },

    clearAll: function () {
      try { localStorage.removeItem(KEY); } catch (e) {}
    }
  };

  G.persistence = persistence;
})(GMB);
