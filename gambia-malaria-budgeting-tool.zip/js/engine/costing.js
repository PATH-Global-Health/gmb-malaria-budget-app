/* Budget engine — costing (pure, DOM-free).
   Joins quantity rows to a cost set by (intervention, type), applies per-unit
   (variable) or fixed (per-year / one-off) costs, and rolls up to cost class. */
window.GMB = window.GMB || {};
GMB.engine = GMB.engine || {};

(function (G) {
  var E = G.engine;

  /** @returns costRows: [{adm1,adm2,year,intervention_code,cost_class,cost_usd,cost_local}] */
  E.applyCosts = function (qrows, costSet) {
    var fx = costSet.exchange_rate || 0, byIv = {};
    (costSet.rows || []).forEach(function (r) { (byIv[r.intervention_code] = byIv[r.intervention_code] || []).push(r); });
    var out = [];
    qrows.forEach(function (qr) {
      var rows = byIv[qr.intervention_code] || [], byClass = {};
      rows.forEach(function (cr) {
        if (cr.type && cr.type !== qr.type) return; // type-specific line that doesn't match the chosen commodity
        var unit = (cr.unit || "").toLowerCase(), cu = cr.usd_cost || 0, costUsd;
        if (/one.?off|once/.test(unit)) costUsd = cu;          // fixed, one-off
        else if (/year/.test(unit)) costUsd = cu;              // fixed, per year
        else costUsd = qr.quantity * cu;                        // variable, per unit
        byClass[cr.cost_class] = (byClass[cr.cost_class] || 0) + costUsd;
      });
      Object.keys(byClass).forEach(function (cc) {
        out.push({ adm1: qr.adm1, adm2: qr.adm2, year: qr.year, intervention_code: qr.intervention_code, cost_class: cc, cost_usd: byClass[cc], cost_local: byClass[cc] * fx });
      });
    });
    return out;
  };
})(GMB);
