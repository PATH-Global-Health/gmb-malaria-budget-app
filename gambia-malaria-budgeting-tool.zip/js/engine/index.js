/* Budget engine — orchestrator. generateBudget(scenario, costSet) → budget object. */
window.GMB = window.GMB || {};
GMB.engine = GMB.engine || {};

(function (G) {
  var E = G.engine;

  // Fingerprint of the inputs, so a saved budget can detect when its source changed.
  E.sourceSig = function (scn, costSet) {
    return G.util.hash(JSON.stringify(scn) + "|" + JSON.stringify(costSet));
  };

  // Verification notes: enabled interventions that ended up costing $0
  // (no quantities, or no matching cost lines — e.g. IPTp with no cost rows).
  E.budgetNotes = function (scn, agg) {
    var notes = [], present = {};
    (agg.byIntervention || []).forEach(function (x) { present[x.intervention_code] = x.cost_usd; });
    G.catalog.forEach(function (c) {
      var iv = scn.interventions[c.code];
      if (iv && iv.enabled && !present[c.code]) {
        notes.push(c.nice + ": switched on but contributes $0 (no quantities, or no matching cost lines in this cost set)");
      }
    });
    return notes;
  };

  E.generateBudget = function (scn, costSet) {
    var q = E.quantify(scn);
    var c = E.applyCosts(q, costSet);
    var agg = E.aggregate(c, scn, costSet);
    return {
      id: "bud_" + Math.random().toString(36).slice(2, 9),
      scenarioId: scn.id, costSetId: costSet.id,
      scenarioName: scn.name, costSetName: costSet.name,
      name: scn.name + " × " + costSet.name,
      generatedAt: new Date().toISOString(),
      sourceSig: E.sourceSig(scn, costSet),
      notes: E.budgetNotes(scn, agg),
      quantityRows: q, costRows: c, aggregates: agg, schemaVersion: 1
    };
  };
})(GMB);
